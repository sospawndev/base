<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'sospawn';
$config['googleplus']['client_id']        = '226599548480-7ped0aegdl64h423vlterj8drsffe13t.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = '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';
$config['googleplus']['redirect_uri']     = 'https://user.sospawn.com/google/oaths.html'; 
$config['googleplus']['api_key']          = 'AIzaSyBGbAhkV5mYDjLC2V8mpxTFvkC59WbeOsc';
$config['googleplus']['scopes']           = array('email','profile');

